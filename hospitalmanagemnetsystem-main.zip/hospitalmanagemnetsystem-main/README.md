# Hospital Management
# For Full working project
# Home page 
![image](https://user-images.githubusercontent.com/86907511/191170844-370e2a61-2c06-41f6-95fc-d6a9ad08c219.png)
# Admin page
![image](https://user-images.githubusercontent.com/86907511/191171004-75f50776-4af3-4cab-80da-1913392d1720.png)

![image](https://user-images.githubusercontent.com/86907511/191171047-91c654b6-af71-427a-9bd2-dee5750b583e.png)
# Patient page
![image](https://user-images.githubusercontent.com/86907511/191171108-ff5eacf4-fd1a-44c6-8f9f-ebc7e2a650a1.png)

![image](https://user-images.githubusercontent.com/86907511/191171136-dea06a39-8793-4d7e-9e8e-4b7ba637ef90.png)
# Doctor Page
![image](https://user-images.githubusercontent.com/86907511/191171198-01355ead-3f29-4828-954f-d6703d79c638.png)

![image](https://user-images.githubusercontent.com/86907511/191171215-b6322e26-8921-4ee0-84e8-6eafa168964e.png)
# About Us
![image](https://user-images.githubusercontent.com/86907511/191171257-bfdbce18-35f7-4eed-835d-e19e903ba180.png)
# Contact us
![image](https://user-images.githubusercontent.com/86907511/191171311-8c69b795-de6b-4cc9-a404-9271eba78d3d.png)
